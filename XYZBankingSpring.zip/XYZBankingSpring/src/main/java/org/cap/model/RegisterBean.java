package org.cap.model;

import java.util.ArrayList;
//import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;


@Entity
@Table(name="customer")
@SecondaryTable(name="address")
public class RegisterBean {

	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int customer_id;
	
	@NotEmpty(message="*First Name cannot be empty!")
	private String first_name;
	@NotEmpty(message="*Last Name cannot be empty!")
	private String last_name;
	
	@Column(table="address")
	private String address_line1;
	@Column(table="address")
	private String address_line2;
	@Column(table="address")
	private String city;
	@Column(table="address")
	private String state;
	@Column(table="address", name="pin_code")
	@Length(min=6,max=6,message="*Enter a valid 6 digit pincode.")
	private String pincode;
	
	@Length(min=10,max=10,message="*Enter a 10 digit mobile number.")
	@Column(name="mobile_no")
	private String mobileNumber;
	
	private String gender;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@Past(message="*Enter date of birth before current date!")
	private Date date_of_birth;
	
	@Range(min=2000, max=5000, message="*Fees should be between Rs.2000 and Rs.5000.")
	private double registration_fees;
	
	@Email(message="*Please provide a valid Email ID!")
	@NotEmpty(message="*Please enter Email ID!")
	private String email_id;
	
	@Column(name="customer_pwd")
	@Length(min=6,max=10,message="*Password length should be between 6 to 10 characters.")
	private String password;
	
	@Transient
	private String confirmPassword;
	
	
	@OneToMany(mappedBy="customer", targetEntity=Account.class,cascade=CascadeType.MERGE,fetch = FetchType.EAGER)
	private List<Account> accounts=new ArrayList<Account>();

    

	public RegisterBean(int customer_id, String first_name, String last_name, String address_line1,
			String address_line2, String city, String state, String pincode, String mobileNumber, String gender,
			Date date_of_birth, double registrationFees, String email_id, String password, String confirmPassword,
			List<Account> accounts) {
		super();
		this.customer_id = customer_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.address_line1 = address_line1;
		this.address_line2 = address_line2;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.mobileNumber = mobileNumber;
		this.gender = gender;
		this.date_of_birth = date_of_birth;
		this.registration_fees = registrationFees;
		this.email_id = email_id;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.accounts = accounts;
	}



	@Override
	public String toString() {
		return "RegisterBean [customer_id=" + customer_id + ", first_name=" + first_name + ", last_name=" + last_name
				+ ", address_line1=" + address_line1 + ", address_line2=" + address_line2 + ", city=" + city
				+ ", state=" + state + ", pincode=" + pincode + ", mobileNumber=" + mobileNumber + ", gender=" + gender
				+ ", date_of_birth=" + date_of_birth + ", registrationFees=" + registration_fees + ", email_id="
				+ email_id + ", password=" + password + ", confirmPassword=" + confirmPassword + ", accounts="
				+ accounts + "]";
	}



	public int getCustomer_id() {
		return customer_id;
	}



	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}



	public String getFirst_name() {
		return first_name;
	}



	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}



	public String getLast_name() {
		return last_name;
	}



	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}



	public String getAddress_line1() {
		return address_line1;
	}



	public void setAddress_line1(String address_line1) {
		this.address_line1 = address_line1;
	}



	public String getAddress_line2() {
		return address_line2;
	}



	public void setAddress_line2(String address_line2) {
		this.address_line2 = address_line2;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getState() {
		return state;
	}



	public void setState(String state) {
		this.state = state;
	}



	public String getPincode() {
		return pincode;
	}



	public void setPincode(String pincode) {
		this.pincode = pincode;
	}



	public String getMobileNumber() {
		return mobileNumber;
	}



	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}



	public String getGender() {
		return gender;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}



	public Date getDate_of_birth() {
		return date_of_birth;
	}



	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}



	public double getRegistration_fees() {
		return registration_fees;
	}



	public void setRegistration_fees(double registrationFees) {
		this.registration_fees = registrationFees;
	}



	public String getEmail_id() {
		return email_id;
	}



	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getConfirmPassword() {
		return confirmPassword;
	}



	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}



	public List<Account> getAccounts() {
		return accounts;
	}



	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}



	public RegisterBean()	{}
	
}
