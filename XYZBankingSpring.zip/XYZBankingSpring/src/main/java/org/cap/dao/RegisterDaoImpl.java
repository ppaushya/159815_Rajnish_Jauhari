package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.cap.model.RegisterBean;
import org.springframework.stereotype.Repository;

@Repository("registerDao")
@Transactional
public class RegisterDaoImpl implements IRegisterDao	{

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public boolean registerDetails(RegisterBean registerBean) {
		em.persist(registerBean);
		return true;
	}

	@Override
	public List<RegisterBean> getAllRegistrations() {
		
		return (List<RegisterBean>) em.createQuery("from RegisterBean").getResultList();
		
	}

	@Override
	public void deleteRegistration(int customerId) {
		RegisterBean register=em.find(RegisterBean.class, customerId);
		em.remove(register);
	}
	
	@Override
	public RegisterBean findRegistration(int customerId) {
		RegisterBean register= em.find(RegisterBean.class, customerId);
		
		return register;
	}

	public void updateRegistration(RegisterBean registerBean)	{
		em.merge(registerBean);
	}
	
	@Override
	public RegisterBean isValidLogin(RegisterBean registerBean) {
		RegisterBean loginData;
		String sql="from RegisterBean where email_id=:userName and customer_pwd=:userPwd";
		Query query= em.createQuery(sql);
		query.setParameter("userName", registerBean.getEmail_id());
		query.setParameter("userPwd", registerBean.getPassword());
		
		List<RegisterBean> list= query.getResultList();
		if(!list.isEmpty())
			loginData=list.get(0);
		else 
			loginData=null;
		
		return loginData;
	}
	
}
