export interface ISalesAnalysis {
    productCategory: string;
    productQuantity: number;
    productSales: number;
    salesPercent: number;
    merchant: string;
}