
public class Validation {
	
	public int validateID(String customerID)
	{
		if(customerID.matches("\\d{6,10}"))
		{	return 1;	}
		else
			{System.out.println("Customer ID should be between 6-10 digits");
			return 0;
			}
	}
	
	public int validateName(String customerName)
	{
		if(customerName.matches("[A-Za-z]+"))
		{	return 1;	}
		else
			{System.out.println("Customer Name should contain only alphabets");
			return 0;
			}
	}
	
	public int validateEmail(String email)
	{
		if(email.matches("[a-z0-9.]+@gmail.com"))
		{	return 1;	}
		else
			{System.out.println("Enter a valid email");
			return 0;
			}
	}
	
	public int validateMobile(String mobile)
	{
		if(mobile.matches("\\d{10}"))
		{	return 1;	}
		else
			{System.out.println("Enter a 10 digit mobile number!");
			return 0;
			}
	}

}
