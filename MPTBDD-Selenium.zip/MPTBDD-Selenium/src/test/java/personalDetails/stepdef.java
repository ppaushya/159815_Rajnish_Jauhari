package personalDetails;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {

	private WebDriver webdriver;
	private String title,heading;
	
	@Before
	public void setup() {
		
		System.getProperty("webdriver.chrome.driver","C:\\Users\\rjauhari\\Downloads\\chromedriver.exe");
		webdriver= new ChromeDriver();
	}
	
	@Given("^Conference Registration Page$")
	public void conference_Registration_Page() throws Throwable {
		webdriver.get("C:/Users/mbommath/Downloads/Conferencebooking/ConferenceRegistartion.html");
	}

	@When("^Title is invalid$")
	public void title_is_invalid() throws Throwable {
		title = webdriver.getTitle();
		assertNotEquals("Conference Registration", title);
	}

	@Then("^Stop testing$")
	public void stop_testing() throws Throwable {
		webdriver.quit();
	}

	@When("^Heading is invalid$")
	public void heading_is_invalid() throws Throwable {
		heading = webdriver.findElement(By.tagName("h2")).getText();
		assertNotEquals("Personal Details", title);
	}

	@When("^FirstName is invalid$")
	public void firstname_is_invalid() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("");
		webdriver.findElement(By.tagName("a")).click(); 
	}

	@Then("^alert the user with 'Please Enter Valid FirstName'$")
	public void alert_the_user_with_Please_Enter_Valid_FirstName() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Please fill the First Name", alertFN);
		if(alertFN.equals("Please fill the First Name"))
			System.out.println("true");
		else System.out.println("false"); 
	}

	@When("^LastName is invalid$")
	public void lastname_is_invalid() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Ram");
		webdriver.findElement(By.name("txtLN")).sendKeys("");
		webdriver.findElement(By.tagName("a")).click(); 
	}

	@Then("^alert the user with 'Please Enter Valid LastName'$")
	public void alert_the_user_with_Please_Enter_Valid_LastName() throws Throwable {
			String alertFN=webdriver.switchTo().alert().getText();
					assertEquals("Please fill the Last Name", alertFN);
					if(alertFN.equals("Please fill the Last Name"))
						System.out.println("true");
					else System.out.println("false"); 
	}

	@When("^Email is invalid$")
	public void email_is_invalid() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Ram");
		webdriver.findElement(By.name("txtLN")).sendKeys("Singh");
		webdriver.findElement(By.name("Email")).sendKeys("");
		webdriver.findElement(By.tagName("a")).click(); 
	}

	@Then("^alert the user with 'Please Enter Valid Email'$")
	public void alert_the_user_with_Please_Enter_Valid_Email() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Please fill the email", alertFN);
		if(alertFN.equals("Please fill the email"))
			System.out.println("true");
		else System.out.println("false"); 
	}

	@When("^ContactNo is invalid$")
	public void contactno_is_invalid() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Ram");
		webdriver.findElement(By.name("txtLN")).sendKeys("Singh");
		webdriver.findElement(By.name("Email")).sendKeys("ram@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("1234567890");
		webdriver.findElement(By.tagName("a")).click(); 
	}

	@Then("^alert the user with 'Please Enter Valid ContactNo'$")
	public void alert_the_user_with_Please_Enter_Valid_ContactNo() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Please enter valid Contact no.", alertFN);
		if(alertFN.equals("Please enter valid Contact no."))
			System.out.println("true");
		else System.out.println("false"); 
	}

	@When("^NoOfPeople is invalid$")
	public void noofpeople_is_invalid() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Ram");
		webdriver.findElement(By.name("txtLN")).sendKeys("Singh");
		webdriver.findElement(By.name("Email")).sendKeys("ram@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("9876543210");
		Select select = new Select(webdriver.findElement(By.name("size")));
		webdriver.findElement(By.tagName("a")).click(); 
	}

	@Then("^alert the user with 'Enter Number of People'$")
	public void alert_the_user_with_Enter_Number_of_People() throws Throwable {
	    
	}

	@When("^all the fields are valid$")
	public void all_the_fields_are_valid() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Please fill the Number of people attending", alertFN);
		if(alertFN.equals("Please fill the Number of people attending"))
			System.out.println("true");
		else System.out.println("false"); 
	}

	@Then("^display the 'Personal Details are Validated'$")
	public void display_the_Personal_Details_are_Validated() throws Throwable {  
			webdriver.findElement(By.name("txtFN")).sendKeys("Ram");
					webdriver.findElement(By.name("txtLN")).sendKeys("Singh");
					webdriver.findElement(By.name("Email")).sendKeys("ram@gmail.com");
					webdriver.findElement(By.name("Phone")).sendKeys("9876543210");
					Select select = new Select(webdriver.findElement(By.name("size")));
					select.selectByIndex(1);
					webdriver.findElement(By.name("Address")).sendKeys("MIPL");
					webdriver.findElement(By.name("Address2")).sendKeys("Mahindra World City");
					Select selectCity = new Select(webdriver.findElement(By.name("city")));
					selectCity.selectByIndex(1);
					Select selectState = new Select(webdriver.findElement(By.name("state")));
					selectState.selectByIndex(1);
					webdriver.findElement(By.name("memberStatus")).click();
					webdriver.findElement(By.tagName("a")).click();
	}

	@Then("^Navigation to next Page$")
	public void navigation_to_next_Page() throws Throwable {
		webdriver.switchTo().alert().accept();
	    webdriver.navigate().to("C:/Users/rjauhari/Documents/Conferencebooking/Conferencebooking/PaymentDetails.html");
	}


	
}
