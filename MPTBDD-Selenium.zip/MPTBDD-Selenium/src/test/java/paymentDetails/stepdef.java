package paymentDetails;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {

	private WebDriver webdriver;
	
	@Before
	public void setup() {
		
		System.getProperty("webdriver.chrome.driver","C:\\Users\\rjauhari\\Downloads\\chromedriver.exe");
		webdriver= new ChromeDriver();
	}

	
	@Given("^user details$")
	public void user_details() throws Throwable {
	   webdriver.get("C:/Users/rjauhari/Documents/Conferencebooking/Conferencebooking/PaymentDetails.html");
	}

	@When("^all fields are valid$")
	public void all_fields_are_valid() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Ram");
		webdriver.findElement(By.name("debit")).sendKeys("Singh");
		webdriver.findElement(By.id("txtCvv")).sendKeys("987");
		webdriver.findElement(By.id("txtMonth")).sendKeys("10");
		webdriver.findElement(By.id("txtYear")).sendKeys("1996");
	}

	@Then("^display 'Registration Successful' in alert box$")
	public void display_Registration_Successful_in_alert_box() throws Throwable {
		webdriver.findElement(By.id("btnPayment")).click();
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Conference Room Booking successfully done!!!", alertFN);
		webdriver.switchTo().alert().accept();
	}
	
}
