import { Inventory } from "./Inventory";
import { Promos } from "./Promos";

export interface Product{
    "productId":number;
    "productName":string;
    "productCategory":string;
    "inventory":Inventory;
    "productPrice":number;
    "promo":Promos;
    "productsSold":number;
    "productView":number;
    "isPromotionMessageSent":boolean;
    "productDescription":string;
    "quantity":number;
    "discount":number;
    "brand":string;
}