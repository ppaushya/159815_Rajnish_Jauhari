import { Address } from "./Address";

export interface Shipment{
    "shipmentId":number;
    "address":Address;
    "product":string;
    "deliveryDate":Date;
    "dispatchDate":Date;
    "deliveryStatus":string;
    "changedDeliveryStatus":string;
}